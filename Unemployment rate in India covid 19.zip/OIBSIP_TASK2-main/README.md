# OIBSIP_TASK2
The task was to analyze the unemployment rate in India during the COVID-19 pandemic.
